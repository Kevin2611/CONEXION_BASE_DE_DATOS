﻿Public Class Form1
    Private Sub DatospersonalesBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles DatospersonalesBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.DatospersonalesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.DATOSPERSONALESDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'DATOSPERSONALESDataSet.datospersonales' Puede moverla o quitarla según sea necesario.
        Me.DatospersonalesTableAdapter.Fill(Me.DATOSPERSONALESDataSet.datospersonales)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click

    End Sub
End Class
